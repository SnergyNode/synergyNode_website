<?php
$active['servic'] = 'nav-active';
?>



<?php $__env->startSection('content'); ?>
    <div class="col-md-12">

        <nav class="row" style="margin: 0 4px">
            <ol class="breadcrumb radius50">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item"><span><b>Our Services</b></span></li>
            </ol>
        </nav>

        <!-- first div panel for greeting and important messages-->

        <?php echo $__env->make('admin.include.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="" style="margin-top: 50px">

            <div class="row" >
                <div class="col-md-12">
                    <a href="<?php echo e(route('servic.create')); ?>" class="btn btn-orange-border btn-lg btn-sm">New Service</a>
                </div>
                <div class="col-sm-12" style="margin-top: 20px">
                    <table class="table table-striped table-bordered table-hover table-checkable order-column valign-middle dataTable no-footer"
                           id="" role="grid" aria-describedby="">
                        <thead>
                        <tr role="row">

                            <th class="sorting" tabindex="0" aria-controls="example4"
                                rowspan="1" colspan="1" style="width: 57px;"> Title </th>
                            <th class="sorting" tabindex="0" aria-controls="example4"
                                rowspan="1" colspan="1" style="width: 222px;">Intro </th>
                            <th class="sorting" tabindex="0" aria-controls="example4"
                                rowspan="1" colspan="1" style="width: 137px;">  Status </th>
                            <th class="sorting" tabindex="0"
                                aria-controls="example4" rowspan="1" colspan="1"
                                style="width: 47px;"> Action </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $servic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="gradeX odd" role="row">
                                <td><?php echo e($service->title); ?></td>
                                <td style="width: 222px;"><?php echo e($service->intro()); ?></td>
                                <td><?php echo e($service->status===1?'Active':'Disabled'); ?></td>
                                <td>
                                    <a href="<?php echo e(route('servic.show', $service->unid)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i> Preview</a>
                                    <a href="" class="btn btn-danger btn-sm"><i class="fa fa-remove"></i> Disable</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5">
                                    <p>No Records Found</p>
                                </td>
                            </tr>
                        <?php endif; ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>