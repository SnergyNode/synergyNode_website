<?php if(session('status')): ?>
    <div class="alert alert-success radius50" style="margin: 0 15px 20px 15px">
        <?php echo e(session('status')); ?>

    </div>
    <br>
<?php endif; ?>

<?php if(session('message')): ?>
    <br>
    <div class="alert alert-info radius50" style="margin: 0 15px 20px 15px">
        <?php echo session('message'); ?>

        <a href="#" class="close pull-right" data-dismiss="alert" aria-label="close">&times;</a>
    </div>

<?php endif; ?>

<?php if(count($errors) > 0): ?>
    <br>
    <div >
        <ul class="list-unstyled">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="alert alert-danger radius50" style="margin: 0 15px 20px 15px" >
                    <i class="fa fa-warning" style="margin: 0px 9px"></i> <?php echo e($error); ?>

                    <a href="#" class="close pull-right" data-dismiss="alert" aria-label="close">&times;</a>
                </li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

<?php endif; ?>