<?php $title = 'Synergy Node - Articles';
    $active['articles'] = 'active';
?>


<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('pages.layout.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!--slider start-->
   <?php echo $__env->make('pages.layout.particles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!--start services-->

    <section id="services" class="all-space" style="min-height: 70vh">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="row">
                        <div class="col-md-12">
                            <h6 class="text-left">Related to <span style="color: orangered"><?php echo e($tag); ?></span></h6>
                            <hr>
                        </div>
                        <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-md-12">

                                <div>
                                    <div class="card" style="border-radius: 0">
                                        <a href="<?php echo e(route('home.blog.show',$article->slug )); ?>" class="card-img">
                                            <div class="img-frame" style="max-height: 250px; overflow: hidden;">
                                                <img src="<?php echo e(url($article->banner)); ?>" alt="">
                                            </div>
                                        </a>
                                        <div class="" style="padding-top: 5px">
                                            <p class="col-md-12 gray-text text-left">
                                                <small>
                                                    SYNERGY<b style="color: orangered">NODE</b> ARTICLE | UPDATED: <?php echo e(date('F d, Y', strtotime($article->updated_at))); ?>

                                                </small>
                                            </p>

                                            <h5 class="text-left col-md-12" style="color: orangered">
                                                <a href="<?php echo e(route('home.blog.show',$article->slug )); ?>">
                                                    <?php echo e($article->title); ?>

                                                </a>
                                            </h5>
                                            <p class="text-left col-md-12"><small>
                                                    <?php echo e($article->desc); ?>

                                                </small>
                                            </p>

                                        </div>
                                        <div class="card-footer tagfoot">
                                            <?php echo $__env->make('pages.blog.relative', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-center" style="width: 100%">
                                <span style="font-size: 50px; color: red"><i class="fa fa-newspaper-o"></i></span>
                                <b>No Publications at the moment... Check back later. Thanks.</b>
                            </p>
                        <?php endif; ?>

                    </div>
                </div>
                <div class="col-md-3">
                    <?php echo $__env->make('pages.blog.sidenav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
    </section>

    <div class="height-60"> </div>
    <!-- footer Section -->
    <!-- <div class="map">
         <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3555.6723566350543!2d75.69413081435708!3d26.97727316380369!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db2d041388711%3A0x300004512954193e!2sNiwaru+Rd%2C+Peethawas%2C+Rajasthan+302012!5e0!3m2!1sen!2sin!4v1473494573015" allowfullscreen></iframe>
     </div>-->

    <!-- footer Section -->
    <?php echo $__env->make('pages.include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>