<div class="card mt-4">
    <div class="card-body">

        <h6>Assigned Teams

            <a href="<?php echo e(route('team.create', $project->id)); ?>" title="Click to add Team Members" class="btn btn-dark pull-right" rel="modal:open"> <i class="fa fa-plus"></i></a>
        </h6>
        <hr>
        <div class="row">
            <div class="col-sm-3">
                <img src="<?php echo e(url('images/synergy.png')); ?>" alt="" class="img-fit img-round">
            </div>
            <div class="col-sm-9">
                <p class="text-black mb-0"><b>Synergy Node Ltd</b></p>
                <p class="mb-0"><small><?php echo e(_('info@synergynode.com')); ?></small></p>
                <p class="mb-0"><b><small><?php echo e(_('Project Manager')); ?></small></b></p>

            </div>
        </div>
        <hr>

        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row mb-2">
                <div class="col-sm-3 text-center">
                    <img src="<?php echo e(url($team->user()->setPhoto())); ?>" alt="" class="img-tiny img-round">
                </div>
                <div class="col-sm-9">
                    <p class="text-black mb-0 fs-12"><b><?php echo e($team->user()->setName()); ?></b></p>
                    <p class="mb-0 fs-12"><small><?php echo e($team->team_lead?'Team Lead':''); ?></small></p>
                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>