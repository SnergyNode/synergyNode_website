<section class="counter-section bg-parallax" data-jarallax='{"speed": 0.2}' style="background: url(images/bg-1.jpg) no-repeat center center;">
    <div class="container">
        <div class="row d-none">
            <div class="col-lg-12 scrollReveal sr-bottom sr-ease-in-out-quad sr-delay-1">
                <!--<h1 class="section-heading">counter</h1>-->
                <!--<p>dummy info here</p>-->
            </div>
        </div>
        <div class="row">
            <div class="col-lg-3 col-sm-6 mb-5  col-md-3">
                <div class="counter  ">
                    <i class="ion-code-working"></i>
                    <span class="count">15742</span>
                    <label>LINES OF CODE</label>
                    <p class="text-color">... and counting</p>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 mb-5  col-md-3 ">
                <div class="counter ">
                    <i class="ion-ios-people"></i>
                    <span class="count">13</span>
                    <label>TEAM MEMBERS</label>
                    <p class="text-color">They can’t be wrong</p>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 mb-5  col-md-3">
                <div class="counter ">
                    <i class="ion-ios-home"></i>
                    <span class="count">6</span>
                    <label>OUR OFFICES</label>
                    <p class="text-color">Another one coming</p>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 mb-5  col-md-3">
                <div class="counter ">
                    <i class="ion-ios-people"></i>
                    <span class="count">27</span>
                    <label>CLIENTS</label>
                    <p class="text-color">amazing testimonies</p>
                </div>
            </div>
        </div>
    </div>
</section>