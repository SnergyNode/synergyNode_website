<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title> Dashboard</title>

    <!-- site icon -->
    
    <link rel="shortcut icon" href="<?php echo e(url("images/logo2.png")); ?>" type="image/x-icon"/>

    <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(url("images/logo2.png")); ?>" />
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(url("images/logo2.png")); ?>" />


    <!-- Styles -->
    

    <link href="<?php echo e(asset("assets/bootstrap/dist/css/bootstrap.min.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(asset("css/font-awesome.min.css")); ?>" rel="stylesheet">

    <link href="<?php echo e(asset("css/layout.css")); ?>" rel="stylesheet">

    <link href="<?php echo e(asset("css/style.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(asset("css/synergyadmin.css")); ?>" rel="stylesheet" >
    <link href="<?php echo e(asset("assets/ionicons/css/ionicons.min.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(asset("css/admin_responsive.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(asset("css/admin.css")); ?>" rel="stylesheet">



</head>
<body>
<div class="wrapper">
    <?php echo $__env->make('admin.include.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="overlay"></div>

    <div id="content">
        <?php echo $__env->make('admin.include.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="main-content">
            <br>
            <div class="col-12" style="margin-top: 50px">

                <!-- Contents START -->
            <?php echo $__env->yieldContent('content'); ?>

            <!-- Contents END -->

            </div>
        </div>

    </div>
    <!-- Dark Overlay element -->


</div>

<!-- Scripts -->
<script src="<?php echo e(asset("assets/jquery/dist/jquery.min.js")); ?>"></script>
<script src="<?php echo e(asset("assets/tether/dist/js/tether.min.js")); ?>"></script>
<script src="<?php echo e(asset("assets/flexslider/jquery.flexslider-min.js")); ?>"></script>
<script src="<?php echo e(asset("assets/scrollreveal/dist/scrollreveal.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/modernizr.js")); ?>"></script>
<script src="<?php echo e(asset("assets/jarallax/dist/jarallax.min.js")); ?>"></script>
<script src="<?php echo e(asset("assets/jarallax/dist/jarallax-video.min.js")); ?>"></script>
<!-- jQuery -->
<!-- Bootstrap Core JavaScript -->
<script src="<?php echo e(asset("assets/bootstrap/dist/js/bootstrap.min.js")); ?>"></script>
<!-- Scrolling Nav JavaScript -->
<script src="<?php echo e(asset("js/jquery.easing.min.js")); ?>"></script>
<script src="https://hyvecore.herokuapp.com/socket.io/socket.io.js"></script>

<script src="<?php echo e(asset("js/scrolling-nav.js")); ?>"></script>

<!--valid / working contact form js-->
<script src="<?php echo e(asset("assets/owl-carousel/owl.carousel.js")); ?>"></script>

<script src="<?php echo e(asset("js/admin.js")); ?>"></script>
<!--custom js-->

<?php if(isset($jslinks)): ?>
    <?php $__currentLoopData = $jslinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script src="<?php echo e(asset('js/'.$link)); ?>"></script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
</body>
</html>
