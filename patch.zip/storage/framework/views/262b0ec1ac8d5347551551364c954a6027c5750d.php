<?php

$active['project'] = 'nav-active';

?>


<?php $__env->startSection('content'); ?>
    <div class="col-md-12">

        <nav class="row" style="margin: 0 4px">
            <ol class="breadcrumb radius50">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item"><span><b><a href="<?php echo e(route('project.index')); ?>">Projects</a></b></span></li>
                <li class="breadcrumb-item"><span><b><?php echo e($project->title); ?></b></span></li>
            </ol>
        </nav>

        <br>
        <div class="row">
            <div class="col-md-12">
                <a href="<?php echo e(route('project.edit', $project->id)); ?>" class="btn btn-lg btn-white-border">MANAGE PROJECT</a>
            </div>
        </div>

        <!-- first div panel for greeting and important messages-->
        <?php echo $__env->make('admin.include.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row mt-5">
            <div class="col-md-4">

                <?php echo $__env->make('admin.include.projectInfo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <?php echo $__env->make('admin.include.projectTeam', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <?php echo $__env->make('admin.include.projectClient', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </div>
            <div class="col-md-8">
                <?php echo $__env->make('admin.include.projectActivity', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>

    </div>

    <?php echo $__env->make('admin.include.tinymyce', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>