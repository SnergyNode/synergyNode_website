<?php $title = 'Synergy Node - Home'; ?>



<?php $__env->startSection('content'); ?>
    <!--top bar start-->
    <?php echo $__env->make('pages.include.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!--slider start-->
    <?php echo $__env->make('pages.include.sliders', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- steps and about -->
    <?php echo $__env->make('pages.include.about', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Counter-section  -->
    <?php echo $__env->make('pages.include.counter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!--start services-->
    <?php echo $__env->make('pages.include.services', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!--end services-->

    <!-- Quote Section -->
    <?php echo $__env->make('pages.include.quote', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- work Section -->
    <?php echo $__env->make('pages.include.works', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- CLINTS Section -->
    <?php echo $__env->make('pages.include.client', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- contact Section -->
    <?php echo $__env->make('pages.include.contact', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="height-60"> </div>
    <!-- footer Section  with map...map in trash-->

    <?php echo $__env->make('pages.include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>