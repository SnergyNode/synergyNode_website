<!-- Sidebar -->

<nav id="sidebar">
    <br>
    <div class="row">
        <div class="col-sm">
            <h3>
                <p class="text-center">
                    <img class="img-small" src="<?php echo e(url('images/synergy.png')); ?>" alt="">
                </p>
            </h3>
            <div id="dismiss">
                <i class="fa fa-arrow-left"></i>
            </div>
        </div>
    </div>



    <div class="sidebar-header">
        <a href="<?php echo e(route('admin.profile', $person->unid)); ?>"><img src="<?php echo e(url($person->setPhoto())); ?>" class="img-sm img-round" alt=""></a>

        <small style="color: #8c8c8c;"> <b><?php echo e($person->title. ' '. $person->first_name); ?></b></small>

    </div>

    <ul class=" list-unstyled components">
        

        <li>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo e(@$active['dashboard']); ?>"><small>Dashboard</small></a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.index')); ?>" class="<?php echo e(@$active['admin']); ?>"><small>Admin</small></a>
        </li>
        <li>
            <a href="<?php echo e(route('client.index')); ?>" class="<?php echo e(@$active['client']); ?>"><small>Clients</small></a>
        </li>
        <li>
            <a href="<?php echo e(route('visits.index')); ?>" class="<?php echo e(@$active['visits']); ?>"><small>Visits</small></a>
        </li>
        <li>
            <a href="<?php echo e(route('servic.index')); ?>" class="<?php echo e(@$active['servic']); ?>"><small>Services</small></a>
        </li>
        <li>
            <a href="<?php echo e(route('blog.index')); ?>" class="<?php echo e(@$active['blog']); ?>"><small>Blog</small></a>
        </li>
        <li>
            <a href="<?php echo e(route('synergy.index')); ?>" class="<?php echo e(@$active['siteinfo']); ?>"><small>Site Info</small></a>
        </li>
        <li>
            <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false"><small>More</small> <i class="fa fa-chevron-down pull-right"></i></a>
            <ul class="collapse list-unstyled" id="pageSubmenu">
                <li>
                    <a href="<?php echo e(route('quote.index')); ?>">Quotes</a>
                </li>
                <li>
                    <a href="#">Messenger</a>
                </li>
                <li>
                    <a href="#">Visitors</a>
                </li>
            </ul>
        </li>




    </ul>
</nav>