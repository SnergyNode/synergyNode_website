
<!--<section class="counter-section bg-parallax" data-jarallax='{"speed": 0.2}' style="background: url(images/bg-2.jpg) no-repeat center center;">
    <div class="container">
        <div class="row">
            <div class="col-lg-12  col-sm-12 col-md-12">
                <h2 class="parallax-text">" A Super Simple Minimal One Page for Creative & Small Agencies "</h2>
            </div>
        </div>
    </div>
</section>-->
<!-- Team Section -->
<!--<section id="team" class="team-section all-space">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 scrollReveal sr-bottom sr-ease-in-out-quad sr-delay-1">
                <h1 class="section-heading">Our Team</h1>
                <p>Lorem Ipsum is simply dummy text </p>
            </div>
            <div class="height-40"> </div>
            <div class="col-lg-3  col-sm-6 mb-3 ol-md-3 scrollReveal sr-bottom sr-delay-1">
                <div class="team">
                    <div class="team-img" style="background-image:url(images/team4.png)">
                        <div class="team-con ">
                            <h3>Jesse Peterson </h3>
                            <p>Video & Motion Graphics</p>
                            <ul class="list-inline list-unstyled team-socials">
                                <li class="list-inline-item"><a href="index.html#"><i class="ion-social-facebook"></i></a></li>
                                <li class="list-inline-item"><a href="index.html#"><i class="ion-social-twitter"></i></a></li>
                                <li class="list-inline-item"><a href="index.html#"><i class="ion-social-linkedin"></i></a></li>
                                <li class="list-inline-item"> <a href="index.html#"><i class="ion-social-googleplus"></i></a></li>
                                <li class="list-inline-item"><a href="index.html#"><i class="ion-social-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3  col-sm-6 mb-3 ol-md-3 scrollReveal sr-bottom sr-delay-2">
                <div class="team">
                    <div class="team-img" style="background-image:url(images/team3.png)">
                        <div class="team-con ">
                            <h3>Jesse Peterson </h3>
                            <p>Video & Motion Graphics</p>
                            <ul class="list-inline list-unstyled team-socials">
                                <li class="list-inline-item"><a href="index.html#"><i class="ion-social-facebook"></i></a></li>
                                <li class="list-inline-item"><a href="index.html#"><i class="ion-social-twitter"></i></a></li>
                                <li class="list-inline-item"><a href="index.html#"><i class="ion-social-linkedin"></i></a></li>
                                <li class="list-inline-item"> <a href="index.html#"><i class="ion-social-googleplus"></i></a></li>
                                <li class="list-inline-item"><a href="index.html#"><i class="ion-social-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3  col-sm-6 mb-3 ol-md-3 scrollReveal sr-bottom sr-delay-3">
                <div class="team">
                    <div class="team-img" style="background-image:url(images/team2.png)">
                        <div class="team-con ">
                            <h3>Jesse Peterson </h3>
                            <p>Video & Motion Graphics</p>
                            <ul class="list-inline list-unstyled team-socials">
                                <li class="list-inline-item"><a href="index.html#"><i class="ion-social-facebook"></i></a></li>
                                <li class="list-inline-item"><a href="index.html#"><i class="ion-social-twitter"></i></a></li>
                                <li class="list-inline-item"><a href="index.html#"><i class="ion-social-linkedin"></i></a></li>
                                <li class="list-inline-item"> <a href="index.html#"><i class="ion-social-googleplus"></i></a></li>
                                <li class="list-inline-item"><a href="index.html#"><i class="ion-social-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3  col-sm-6 mb-3 ol-md-3 scrollReveal sr-bottom sr-delay-4">
                <div class="team">
                    <div class="team-img" style="background-image:url(images/team1.png)">
                        <div class="team-con ">
                            <h3>Jesse Peterson </h3>
                            <p>Video & Motion Graphics</p>
                            <ul class="list-inline list-unstyled team-socials">
                                <li class="list-inline-item"><a href="index.html#"><i class="ion-social-facebook"></i></a></li>
                                <li class="list-inline-item"><a href="index.html#"><i class="ion-social-twitter"></i></a></li>
                                <li class="list-inline-item"><a href="index.html#"><i class="ion-social-linkedin"></i></a></li>
                                <li class="list-inline-item"> <a href="index.html#"><i class="ion-social-googleplus"></i></a></li>
                                <li class="list-inline-item"><a href="index.html#"><i class="ion-social-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>-->
<!--end Team Section -->


<!-- pricing Section -->
<!--
<section id="pricing" class="pricing-section">
    <div class="container">
        <div class="row no-margin">
            <div class="col-lg-12  text-center">
                <h1 class="section-heading">pricing</h1>
                <p>Lorem Ipsum is simply dummy text </p>
            </div>
        </div>
        <div class="height-60"> </div>
        <div class="row">
            <div class="col-lg-3 col-md-6 mb-5 col-sm-12">
                <div class="pricing-table  scrollReveal sr-bottom sr-ease-in-out-quad sr-delay-1 ">
                    <div class="pricing-head">
                        <div class="price-tag-circle">
                            <span class="price">0</span>
                        </div>
                    </div>
                    <div class="pricing-body">
                        <h4 class="price-title">Free Trial</h4>
                        <ul>
                            <li>Free One Year Domain</li>
                            <li>Free Installation</li>
                            <li>Free 1GB Linux Hosting</li>
                            <li>Unlimited Revision</li>
                            <li>Five Alternative Designs</li>
                            <li>Lifetime Support</li>
                            <li>Moneyback Guaranteed</li>
                        </ul>
                    </div>
                    <div class="pricing-footer">
                        <a href="index.html#" class="btn btn-default btn-pricing">BUY NOW</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-5 col-sm-12">
                <div class="pricing-table  scrollReveal sr-bottom sr-ease-in-out-quad sr-delay-1">
                    <div class="pricing-head">
                        <div class="price-tag-circle">
                            <span class="price">29</span>
                        </div>
                    </div>
                    <div class="pricing-body">
                        <h4 class="price-title">SILVER PLAN</h4>
                        <ul>
                            <li>Free One Year Domain</li>
                            <li>Free Installation</li>
                            <li>Free 1GB Linux Hosting</li>
                            <li>Unlimited Revision</li>
                            <li>Five Alternative Designs</li>
                            <li>Lifetime Support</li>
                            <li>Moneyback Guaranteed</li>
                        </ul>
                    </div>
                    <div class="pricing-footer">
                        <a href="index.html#" class="btn btn-default btn-pricing">BUY NOW</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-5 col-sm-12">
                <div class="pricing-table  scrollReveal sr-bottom sr-ease-in-out-quad sr-delay-1">
                    <div class="pricing-head">
                        <div class="price-tag-circle">
                            <span class="price">59</span>
                        </div>
                    </div>
                    <div class="pricing-body">
                        <h4 class="price-title">GOLDEN PLAN</h4>
                        <ul>
                            <li>Free One Year Domain</li>
                            <li>Free Installation</li>
                            <li>Free 1GB Linux Hosting</li>
                            <li>Unlimited Revision</li>
                            <li>Five Alternative Designs</li>
                            <li>Lifetime Support</li>
                            <li>Moneyback Guaranteed</li>
                        </ul>
                    </div>
                    <div class="pricing-footer">
                        <a href="index.html#" class="btn btn-default btn-pricing">BUY NOW</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-5 col-sm-12">
                <div class="pricing-table  scrollReveal sr-bottom sr-ease-in-out-quad sr-delay-1">
                    <div class="pricing-head">
                        <div class="price-tag-circle">
                            <span class="price">99</span>
                        </div>
                    </div>
                    <div class="pricing-body">
                        <h4 class="price-title">PLATINUM PLAN</h4>
                        <ul>
                            <li>Free One Year Domain</li>
                            <li>Free Installation</li>
                            <li>Free 1GB Linux Hosting</li>
                            <li>Unlimited Revision</li>
                            <li>Five Alternative Designs</li>
                            <li>Lifetime Support</li>
                            <li>Moneyback Guaranteed</li>
                        </ul>
                    </div>
                    <div class="pricing-footer">
                        <a href="index.html#" class="btn btn-default btn-pricing">BUY NOW</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
-->


<!-- trash -->
<!-- <div class="map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3555.6723566350543!2d75.69413081435708!3d26.97727316380369!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db2d041388711%3A0x300004512954193e!2sNiwaru+Rd%2C+Peethawas%2C+Rajasthan+302012!5e0!3m2!1sen!2sin!4v1473494573015" allowfullscreen></iframe>
    </div>-->

