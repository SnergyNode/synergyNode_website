<section id="home" class="slider-banner">
    <div class="particle-holder">
        <div id="particles-js"></div>
    </div>

</section>