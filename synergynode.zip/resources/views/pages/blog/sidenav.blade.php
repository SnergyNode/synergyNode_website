<div class="row">
    <div class="col-md-12">
        <div class="card" style="border-radius: 0">
            <a href="{{ route('home.quote') }}" class="card-body" style="padding: 10px">
                <small>MAKE YOUR QUOTE</small>
            </a>

        </div>
    </div>

</div>