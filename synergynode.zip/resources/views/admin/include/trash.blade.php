{{--<li>--}}
{{--<a href="{{ route('settins') }}" class="<?=@$active['settings'] ?> "><small>Settings <i class="fa fa-gears pull-right"></i></small></a>--}}
{{--</li>--}}