<div class="card">
    <div class="card-body">
        <h6>Project Activity</h6>
        <form action="">
            <textarea rows="2" name="details" class=" form-control">{!! old('details') !!}</textarea>
            <br>
            <button class="btn btn-dark " type="submit">Update</button>
        </form>
    </div>
</div>

<div class="card mt-5">
    <div class="card-body m-h-200">
        <h6>Activity Time-line</h6>
        <hr>

    </div>
</div>