<?php

namespace App\Http\Controllers;

use App\Hit;
use Illuminate\Http\Request;

class HitController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Hit  $hit
     * @return \Illuminate\Http\Response
     */
    public function show(Hit $hit)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Hit  $hit
     * @return \Illuminate\Http\Response
     */
    public function edit(Hit $hit)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Hit  $hit
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Hit $hit)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Hit  $hit
     * @return \Illuminate\Http\Response
     */
    public function destroy(Hit $hit)
    {
        //
    }
}
