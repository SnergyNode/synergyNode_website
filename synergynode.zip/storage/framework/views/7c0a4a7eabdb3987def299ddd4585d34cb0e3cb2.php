<div class="footer-bottom">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="f-b">Copyright © 2018 All Rights Reserved.</div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="footer-widget-social">
                    <ul>
                        <li><a data-tooltip="facebook" target="_blank" href="<?php echo e('https://'.$synergy->facebook); ?>"><i class="fa fa-facebook"></i></a></li>
                        <li><a data-tooltip="Linkedin" target="_blank" href="<?php echo e('https://'.$synergy->linkd); ?>"><i class="fa fa-linkedin"></i> </a></li>
                        <li><a data-tooltip="twitter" target="_blank" href="<?php echo e('https://'.$synergy->twitter); ?>"><i class="fa fa-twitter"></i></a></li>
                        <li><a data-tooltip="Instagram" target="_blank" href="<?php echo e('https://'.$synergy->instagram); ?>"><i class="fa fa-instagram"></i> </a></li>
                        <li><a data-tooltip="Google-Plus" target="_blank" href="<?php echo e('https://'.$synergy->google); ?>"><i class="fa fa-google-plus"></i> </a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>