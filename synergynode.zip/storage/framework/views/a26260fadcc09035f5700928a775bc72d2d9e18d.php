<?php
$active['servic'] = 'nav-active';

?>


<?php $__env->startSection('content'); ?>
    <div class="col-md-12">

        <nav class="row" style="margin: 0 4px">
            <ol class="breadcrumb radius50">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('servic.index')); ?>">Service</a></li>
                <li class="breadcrumb-item"><span><b><?php echo e($service->title); ?></b></span></li>
            </ol>

            <ol class="breadcrumb radius50" style="margin-left: 20px">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('servic.edit', $service->unid)); ?>">
                        <i class="fa fa-edit"></i> Edit
                    </a>
                </li>
                <li class="breadcrumb-item">
                    <form id="delete_g" action="<?php echo e(route('servic.destroy', $service->unid)); ?>" method="POST" class="d-inline" style="padding: 0;background: none">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('delete')); ?>

                        <button class="" type="submit" style="background: none;border: 0;cursor: pointer; color: red" onclick="
                                    event.preventDefault();
                                    var person = prompt('Type DELETE to complete: ', '');
                                        if (person == null || person == '') {

                                        } else {
                                            if(person==='DELETE'){
                                                document.getElementById('delete_g').submit();
                                            }
                                        }
                                    "><i class="fa fa-trash"></i>
                            Delete
                        </button>
                    </form>
                </li>
            </ol>
        </nav>
        <!-- first div panel for greeting and important messages-->

        <?php echo $__env->make('admin.include.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="" style="margin-top: 50px">

            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-sm-3"><h2><i class="<?php echo e($service->icon); ?>"></i></h2></div>
                        <div class="col-sm-9">
                            <b><?php echo e($service->title); ?></b>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
            <h4>Intro</h4>
            <p><?php echo e($service->intro); ?></p>
            <h4>Details</h4>
            <p><?php echo e($service->detail); ?></p>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>