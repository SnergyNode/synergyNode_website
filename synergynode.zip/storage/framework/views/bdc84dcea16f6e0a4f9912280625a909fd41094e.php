<?php
$active['servic'] = 'nav-active';
$adTitle = 'Dashboard/Edit Service';
?>



<?php $__env->startSection('content'); ?>
    <div class="col-md-12">

        <nav class="row" style="margin: 0 4px">
            <ol class="breadcrumb radius50">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('servic.index')); ?>">Services</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('servic.show', $service->unid)); ?>"><?php echo e($service->title); ?></a></li>
                <li class="breadcrumb-item"><span><b>Edit</b></span></li>
            </ol>
        </nav>

        <!-- first div panel for greeting and important messages-->

        <?php echo $__env->make('admin.include.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <br>
        <br>
        <h3>Edit Services</h3>
        <hr>

        <div class="" style="margin-top: 50px">

            <div class="col-md-12">
                <form method="post" action="<?php echo e(route('servic.update', $service->unid)); ?>" role="form" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('put')); ?>

                    <div class="row">

                        <div class="col-md-6 control-group">
                            <div class="form-group controls">
                                <input type="text" class="form-control" placeholder="Enter Title" name="title" value="<?php echo e($service->title); ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6 control-group">
                            <div class="row">
                                <div class="col-md-2 control-group">
                                    <div class="form-group controls">
                                        <h3 class="ionico text-right"><i class="<?php echo e($service->icon); ?>"></i></h3>
                                    </div>
                                </div>
                                <div class="col-md-10 control-group">
                                    <div class="form-group controls">
                                        <input type="text" class="form-control" onkeyup="$('.ionico > i').attr('class', $(this).val())" placeholder="ion icon class. e.g: ion-android-desktop" name="icon" value="<?php echo e($service->icon); ?>" required>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="col-md-12 control-group">
                            <p id="intro_left"><?php echo e(strlen($service->intro)); ?></p>
                            <div class="form-group controls">
                                <textarea onkeyup="$('#intro_left').text($(this).val().length)" rows="3" class="form-control" placeholder="Intro: max character: 280, min character: 70," name="intro" required><?php echo e($service->intro); ?></textarea>
                            </div>
                        </div>

                        <div class="col-md-12 control-group">
                            <div class="form-group controls">
                                <textarea rows="3" class="myfield form-control" placeholder="Detail. Should match intro" name="detail" required><?php echo e($service->detail); ?></textarea>
                            </div>
                        </div>


                        <div class="col-md-6 control-group">
                            <div class="form-group controls">
                                <textarea rows="1" class="form-control" placeholder="live-url" name="live_url" required><?php echo e($service->live_url); ?></textarea>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-lg btn-white-border">Update Service</button>
                </form>
            </div>
        </div>

    </div>
    <?php echo $__env->make('admin.include.tinymyce', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>