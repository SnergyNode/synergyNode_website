<div class="m-h-200">

    <form action="<?php echo e(route('client.build', $project->id)); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <table class="table table-responsive">
                <thead>
                    <th>Img</th>
                    <th>Name</th>
                    <th>Select</th>
                    <th>Main</th>
                </thead>
                <tbody>

                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <img src="<?php echo e($user->setPhoto()); ?>" alt="" class="img-sm img-round">
                        </td>
                        <td>
                            <?php echo e($user->setName()); ?>

                        </td>
                        <td>
                            <input name="userID[]" type="checkbox" value="<?php echo e($user->id); ?>">
                        </td>
                        <td>
                            <input type="radio" name="teamlead" value="<?php echo e($user->id); ?>">
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-dark">assign</button>
        </div>
    </form>



</div>