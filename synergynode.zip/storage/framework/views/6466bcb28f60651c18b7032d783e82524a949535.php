

<nav class="navbar navbar-dark bg-dark fixed-top shadow" style="background: #EEEEEE; color: #4b4b4b;">
    <div class="">

        <span type="" id="sidebarCollapse" class="">
            <b><i class="fa fa-bars"></i></b>
        </span>

        <span class="pull-right">
            <a href="<?php echo e(route('admin.logout')); ?>"
               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            <i class="fa fa-power-off"></i> Logout
                        </a>
                        <form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
        </span>

        <span class="pull-right" style="margin-right:100px;">Synergy <b>Node</b></span>

        <span class="dropdown pull-right" style="margin-right:100px;">
            <a href="#" class="fa fa-question" data-toggle="dropdown" role="button" aria-expanded="false">
                <?php if(count($alerts)>0): ?>
                    <i class="fa fa-question-circle"></i>
                    <span class="badge badge-top badge-danger"><?php echo e(count($alerts)); ?></span>
                <?php endif; ?>

            </a>
             <ul class="dropdown-menu" role="menu" style="padding: 0;border: transparent; min-width: 240px;">
            <?php $__currentLoopData = $alerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($alert->setRoute()); ?>" class="list-group-item">
                        <small><?php echo e($alert->setMessage($alert->table)); ?></small>
                    </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </ul>


        </span>

    </div>


</nav>

