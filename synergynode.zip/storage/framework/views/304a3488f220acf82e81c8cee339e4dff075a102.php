<section class="counter-section bg-parallax" data-jarallax='{"speed": 0.2}' style="background: url(images/bg-2.jpg) no-repeat center center;">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 ">
                <h3 class="parallax-text text-center">Get your Quote Started? <a href="<?php echo e(route('home.quote')); ?>" class="btn btn-orange-border btn-lg page-scroll">Yes!</a></h3>
            </div>
        </div>
    </div>
</section>