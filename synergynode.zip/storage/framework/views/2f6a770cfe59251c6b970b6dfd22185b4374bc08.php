
    <?php $__currentLoopData = explode('#', $article->tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(!empty($value)): ?>
            <a href="<?php echo e(route('article.tag', trim($value, " "))); ?>" class="btn btn-primary" style="margin: 5px 10px;height: 35px;"><?php echo e(trim($value, " ")); ?></a>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
