<?php
$active['blog'] = 'nav-active';

?>


<?php $__env->startSection('content'); ?>
    <div class="col-md-12">

        <nav class="row" style="margin: 0 4px">
            <ol class="breadcrumb radius50">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('blog.index')); ?>">Blog</a></li>
                <li class="breadcrumb-item"><span><b>New Blog</b></span></li>
            </ol>
        </nav>
        <!-- first div panel for greeting and important messages-->

        <?php echo $__env->make('admin.include.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <br>
        <br>
        <h3>New Blog</h3>
        <hr>

        <div class="" style="margin-top: 50px">

            <div class="row">
                <div class="col-md-12">
                    <form action="<?php echo e(route('blog.store')); ?>" class="form-horizontal" role="form" enctype="multipart/form-data" method="post">
                        <?php echo e(csrf_field()); ?>


                        <fieldset>

                            <div class="row">
                                <label class="col-sm-2 control-label" for="textinput">Slug</label>
                                <div class="col-sm-4">
                                    <input type="text" name="slug" placeholder="slug. e.g: how-to-make-money (no spaces)" class="form-control" required value="<?php echo e(old('slug')); ?>">
                                </div>

                                <label class="col-sm-2 control-label" for="textinput">Category</label>
                                <div class="col-sm-4">
                                    <select name="category_id" class="form-control" id="" required>
                                        <option value=""></option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </select>
                                </div>
                            </div >

                            <br>

                            <div class="row">
                                <label class="col-sm-2 control-label" for="textinput">Type</label>
                                <div class="col-sm-4">
                                    <select name="type" id="" class="form-control">

                                    </select>
                                </div>

                                <label class="col-sm-2 control-label" for="textinput">Banner</label>
                                <div class="col-sm-4">
                                    <input class="form-input form-control" type="file" name="banner" accept="image/*" onchange="shwimg()" id="imgInp" required >
                                </div>
                            </div >

                            <br>
                            <div class="form-group">

                                <div class="col-sm-10">
                                    <p><small style="color: red">note: dimensions must be 950 x 400 pixels </small></p>
                                    <div class="text-center" style="max-height: 400px; padding: 0; border-radius: 5px; margin: 0 auto; background: #a7a7a7">
                                        <img id="imgtoshow"  src="<?php echo e(url('images/default.png')); ?>" class="img-fit-h" alt="">
                                    </div>
                                </div>

                            </div>
                            <br>
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="textinput">Title</label>
                                <div class="col-sm-10">
                                    <textarea type="text" rows="2" name="title" placeholder="Blog Title" class="form-control" required><?php echo e(old('title')); ?></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="textinput">Description</label>
                                <div class="col-sm-10">
                                    <textarea type="text" rows="2" name="desc" placeholder="Blog Description" class="form-control" required><?php echo e(old('desc')); ?></textarea>
                                </div>
                            </div>




                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="textinput">Tags</label>
                                <div class="col-sm-10">
                                    <p><small>please separate each tag with a space and each tag must be one word</small></p>
                                    <textarea type="text" rows="2" name="tags" placeholder="Blog tags related. e.g: #Money #Training #Housing" class="form-control" required><?php echo e(old('tags')); ?></textarea>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="textinput">Detail</label>
                                <div class="col-sm-10">
                                    <textarea rows="20" name="detail" class="myfield form-control"><?php echo old('detail'); ?></textarea>
                                </div>

                            </div >

                            <div class="form-group" style="margin-bottom: 50px">
                                <div class="col-sm-2"></div>
                                <div class="col-sm-10">
                                    <button type="submit" class="btn btn-sm btn-info">Save</button>
                                </div>

                            </div>

                        </fieldset>

                    </form>
                </div>
            </div>
        </div>

    </div>

    <?php echo $__env->make('admin.include.tinymyce', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>